﻿public enum ShipType {
	SUBMARINE, CORVETTE, FRIGATE, CRUISER, AEROCARRIER	// From 1 to 5 spaces
	
	/*
	 * getDescription: The ship type description
	 */
	public String getDescription() {
		switch(this) {
			//case UNKNOWN_SHIP:	return "Desconhecido";
			case SUBMARINE: 	return "Submarino";
			case CORVETTE:		return "Corveta";
			case FRIGATE:		return "Fragata";
			case CRUISER:		return "Cruzador";
			case AEROCARRIER:	return "Porta-aviões";
			default: return;
		}
	}
	
	/**
	 * getSize: Shows the size of that kind of ship
	 */
	public String getSize() {
		return this.ordinal(); // The size is given by its position in the enumeration
	}
		
}

class Ship {
	private int id;
	private byte size = 0;
	private List<Position> positions;
	private List<Position> hits;
	private boolean sunk = false;
	private ShipType type = SUBMARINE;
	
	public Ship(ShipType type) {
		this.Id = 1;
		this.type = type;
		this.size = (byte) this.type;
		sunk = false;
	}
	
	public boolean isSunk() {
		return this.sunk;
	}
	
	public void hit(Position pos) {
		if(positions.indexOf(pos)>=0) 
			hits.add(pos);
		if(hits.equals(positions)) this.sunk = true;
	}
}

class Position implements Comparable<Position> {
	private int line;
	private int column;
	
	Position(long line, long column) {
		this.line=line;
		this.column=column;
	}
	
	int compareTo(Position s) {
		int res = 0;
		if(s.getLine() == this.line && this.column == s.getColumn()) res = 0;
		else if(this.column < s.column || this.line < s.line) res = -1;
		else if(this.column > s.column || this.line > s.line) res = 1;
		return res;
	}
	
	long getLine() {
		return this.line;
	}
	
	long getColumn() {
		return this.column;
	}
}

class Notice {
	private NoticeDirection direction = NoticeDirection.UNKNOWN;
	private NoticeType type = NoticeType.UNKNOWNOWN;

	public enum NoticeDirection { UNKOWN, OUT, IN }
	public enum NoticeType { UNKNOWN, PREPARE, PREPARED, SHOOT, SHOT, HIT, LOOSE, WIN }
	
	public Notice(NoticeDirection dir, NoticeType type) {
	}
}

class Player {
	private Socket connection;
	private String name;
	private List<Ship> ships;
	private List<Position> shots;
	
	enum NoticeSubmission { PREPARE, SHOOT, URHIT, ULOOSE, UWIN };
	enum NoticeReceipt { PREPARED, SHOT, IMHIT, ILOST };
}

class GameSocket {
}

class Game implements Runnable {
	private Player playerOne;
	private Player playerTwo;
	private Player winner = null;
	private Player looser = null;
	
	Game(Player p1, Player p2) {
		this.playerOne = p1;
		this.playerTwo = p2;
	}
	
	void run() {
		int turn = 0;
		playerOne.prepare();
		playerTwo.prepare();
		
		while(!winner && !looser) {
			if(turn%2==0)
				playerOne.shoot();
			else
				playerTwo.shoot();
				
			checkWinner();
		}
		
		endOfGame();
	}
	
	private void checkWinner() {
		if(playerOne.lost() && !playerTwo.lost()) {
			this.looser=playerOne;
			this.winner=playerTwo;
		}
		else if(!playerOne.lost() && playerTwo.lost()) {
			this.looser=playerTwo;
			this.winner=playerOne;
		}
	}
	
	private void endOfGame() {
		winner.send(
	}
}