/*
 * Copyright (C) 2016 Levi Leal Sellan <levi.sellan at gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package warship;

import java.util.List;
import java.util.Random;

/**
 *
 * @author Levi Leal Sellan <levi.sellan at gmail.com>
 */
public class Ship {
    private int id;
    private Position prow;
    private ShipType type;
    private boolean horizontal;
    private List<Position> positions;
    private boolean sunk = false;

    public Ship(ShipType type) {
        this.type = ShipType.SUBMARINE;
        this.prepare(new Random().nextInt(1000000),type);
    }
    
    public Ship(Integer id, ShipType type) {
        this.type = ShipType.SUBMARINE;
        this.prepare(id, type);
    }

    public Ship(Integer id, int type) {
        ShipType st = ShipType.SUBMARINE;

        for ( ShipType t: ShipType.values()) {
            if(t.getSize() == type) {
                st = t;
                break;
            }
        }
        this.prepare(id, st);
    }

    private void prepare(int id, ShipType type) {
        this.id = id;
        this.type = type;
        sunk = false;
    }

    /**
     *
     * @return True if this ship sunk
     */
    public boolean isSunk() {
            return this.sunk;
    }
    
    /**
     *
     * @param prow
     * @param horizontal
     */
    public void placeShip(Position prow, boolean horizontal) {
        this.prow = prow;
        this.horizontal = horizontal;
        if(horizontal == false) {
            for(int i = 0; i < this.type.getSize(); i++)
                this.positions.add(
                        new Position(prow.getLine()+i,prow.getColumn()));
        }
        else {
            for(int i=0;i<this.type.getSize();i++)
                this.positions.add(
                        new Position(prow.getLine(),prow.getColumn()+i));
        }
    }

    /**
     *
     * @param pos
     * @return
     */
    public boolean hit(Position pos) {
        boolean wasHit = false;
        for (Position p : positions) {
            if(pos.compareTo(p) == 0) {
                wasHit = true;
                positions.remove(p);
            }
        }
        if(positions.isEmpty()) this.sunk = true;
        return wasHit;
    }
}
