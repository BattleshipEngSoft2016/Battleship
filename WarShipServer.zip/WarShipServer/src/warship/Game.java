/*
 * Copyright (C) 2016 Levi Leal Sellan <levi.sellan at gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package warship;


/**
 *
 * @author Levi Leal Sellan <levi.sellan at gmail.com>
 */
class Game implements Runnable {
    private final Player playerOne;
    private final Player playerTwo;
    private Player winner = null;
    private Player looser = null;

    Game(Player p1, Player p2) {
            this.playerOne = p1;
            this.playerTwo = p2;
    }

    @Override
    public void run() {
        int turn = 0;
        Position shot;
        playerOne.prepare(); // wait for the fleet positions
        playerTwo.prepare();

        while(winner==null && looser==null) {
            if(turn%2==0) {
                shot = playerOne.shoot();
                playerTwo.hit(shot);
            }
            else {
                shot = playerTwo.shoot();
                playerOne.hit(shot);
            }
            checkWinner();
        }
        endOfGame();
    }

    private void checkWinner() {
            if(playerOne.lost() && !playerTwo.lost()) {
                    this.looser=playerOne;
                    this.winner=playerTwo;
            }
            else if(!playerOne.lost() && playerTwo.lost()) {
                    this.looser=playerTwo;
                    this.winner=playerOne;
            }
    }

    private void endOfGame() {
           // winner.send();
           // looser.send();
    }
}