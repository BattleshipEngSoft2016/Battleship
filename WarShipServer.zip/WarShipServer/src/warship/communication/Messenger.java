/*
 * Copyright (C) 2016 Levi Leal Sellan <levi.sellan at gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package warship.communication;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Levi Leal Sellan <levi.sellan at gmail.com>
 * @param <M>
 * 
 * Responsible for transform classes into JSON 
 *             and transform JSON into classes
 */
public class Messenger<M> {
    private M m;
    private OutputStream out;
    private InputStream in;
    private final Gson gson = new Gson();
    
    public Messenger(InputStream from, OutputStream to) {
        this.in = from;
        this.out = to;
    }
    
    public void send(M message) {
        String text = gson.toJson(message);
        try {
            out.write(text.getBytes());
        } catch (IOException ex) {
            Logger.getLogger(Messenger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public M receive() {
        byte[] buffer = new byte[102400]; // 100k buffer
        int size=0;
        String json = "";
        
        try {
            size = in.available();
            if(size > buffer.length-1) size = buffer.length-1;
            in.read(buffer,0,size);
            json = new String(buffer);
        } catch (IOException ex) {
            Logger.getLogger(Messenger.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(json.length() > 0) {
            m = gson.fromJson(json, (Class<M>) m.getClass());
        }
        return m;
    }
}
