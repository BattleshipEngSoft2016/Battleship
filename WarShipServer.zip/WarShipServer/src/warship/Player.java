/*
 * Copyright (C) 2016 Levi Leal Sellan <levi.sellan at gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package warship;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import warship.communication.FleetMessage;
import warship.communication.Messenger;
import warship.communication.ShipMessage;
import warship.communication.ShootMessage;
import warship.communication.ShotMessage;

/**
 *
 * @author Levi Leal Sellan <levi.sellan at gmail.com>
 */
public class Player {
    private DataOutputStream out;
    private DataInputStream in;
    private String name;
    private List<Ship> fleet;
    private List<Position> shots;

    void prepare() {
        Messenger<FleetMessage> m = new Messenger(in,out);
        FleetMessage f = m.receive();
        
        for( ShipMessage s: f.getFleet() ) {
            Ship ship;
            ship = new Ship(s.getId(),s.getType());
            ship.placeShip(s.getProw(),s.isHorizontal());
            this.fleet.add(ship);
        }
    }

    public Player(String name,Socket connection) {
        this.name = name;
        try {
            this.out = (DataOutputStream) connection.getOutputStream();
            this.in = (DataInputStream) connection.getInputStream();                
        } catch (IOException ex) {
            Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.fleet = new ArrayList();
    }

    public Position shoot() { // Mensagem para o player atirar
        Position shot;
        Messenger<ShootMessage> shootMailer = new Messenger(in,out);
        Messenger<ShotMessage> shotMailer = new Messenger(in,out);
        ShootMessage shootMessage = new ShootMessage();
        ShotMessage shotMessage;
        shootMailer.send(shootMessage);
        
        shotMessage = shotMailer.receive();
        
        shot = shotMessage.getShot();
        
        return shot;
    }

    void hit(Position shot) {
        Messenger<ShotMessage> m = new Messenger(in,out);
        ShotMessage sm = m.receive();
    }

    boolean lost() {
        int count, fleetSize;
        count=fleetSize = this.fleet.size();
        for(Ship s: fleet) {
            if(s.isSunk()) count--;
        }
        return (count>0);
    }
}
