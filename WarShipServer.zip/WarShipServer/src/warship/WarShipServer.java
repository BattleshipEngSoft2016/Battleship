/*
 * Copyright (C) 2016 Levi Leal Sellan <levi.sellan at gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package warship;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import warship.communication.ConnectedMessage;
import warship.communication.Messenger;

/**
 *
 * @author lsellan
 */
public class WarShipServer {
    private boolean running;
    private ServerSocket connection;
//    private List<Game> games;

    public WarShipServer(int port) {
        if(port <= 1024) {
            port = 7654;
        }
        
        try {
            connection = new ServerSocket(port);
        } catch (IOException ex) {
            Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(-1);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WarShipServer bsServer;

        System.out.println("Iniciando BattleShipServer...");
        
        bsServer = new WarShipServer(Integer.parseInt(args[1]));
        
        bsServer.run();
    }

    private void run() {
        Messenger<ConnectedMessage> m;
        Socket conn1, conn2;
        Game game;
        Player p1, p2;
        running = true;
        
        try {

            while(running) {
                System.out.println("Aguardando jogadores.");
                conn1 = this.connection.accept();
                
                m = new Messenger(
                        (DataInputStream)conn1.getInputStream(), 
                        (DataOutputStream) conn1.getOutputStream());
                m.send(new ConnectedMessage());
                
                System.out.println("Aguardando segundo jogador.");
                conn2 = this.connection.accept();
                m = new Messenger(
                        (DataInputStream)conn1.getInputStream(), 
                        (DataOutputStream) conn1.getOutputStream());
                m.send(new ConnectedMessage());
                
                p1 = new Player("Jogador1", conn1);
                p2 = new Player("Jogador2", conn2);
                
                System.out.println("Iniciando novo Jogo.");
                game = new Game(p1,p2);
                new Thread(game).start();
            }
        } catch (IOException ex) {
            Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
