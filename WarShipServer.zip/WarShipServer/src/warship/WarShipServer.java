/*
 * Copyright (C) 2016 Levi Leal Sellan <levi.sellan at gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package warship;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.bind.DatatypeConverter;
import warship.communication.ConnectedMessage;
import warship.communication.Messenger;

/**
 *
 * @author lsellan
 */
public class WarShipServer {
    private boolean running;
    private ServerSocket connection;
//    private List<Game> games;

    public WarShipServer(int port) {
        if(port <= 1024) {
            port = 7654;
        }
        try {
            connection = new ServerSocket(port);
        } catch (IOException ex) {
            Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(-1);
        }
        System.out.println(System.lineSeparator() + 
                "Warship Server iniciado no endereco "+
                connection.getInetAddress().getHostName()+" porta "+
                connection.getLocalPort());
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WarShipServer wsServer = null;
        int port=7654;

        System.out.println("Iniciando WarShipServer...");
        if( args.length > 0)
            port = Integer.parseInt(args[0]);
        
        wsServer = new WarShipServer(port);
        
        wsServer.run();
    }

    private void run() {
        Messenger<ConnectedMessage> m;
        Socket conn1, conn2;
        Game game;
        Player p1, p2;
        running = true;
        
        try {

            while(running) {
                byte[] buffer = new byte[102400];
                System.out.println("Aguardando jogadores.");
                conn1 = this.connection.accept();
                handshake(conn1);
                m = new Messenger(conn1.getInputStream(), 
                        conn1.getOutputStream());
                conn1.getInputStream().read(buffer, 0, buffer.length-1);
                System.out.println(buffer);
                
                m.send(new ConnectedMessage());
                
                System.out.println("Aguardando segundo jogador.");
                conn2 = this.connection.accept();
                handshake(conn2);
                conn1.getInputStream().read(buffer, 0, buffer.length-1);
                System.out.println(new String(buffer));
                
                m = new Messenger(conn2.getInputStream(), 
                        conn2.getOutputStream());
                m.send(new ConnectedMessage());
                
                p1 = new Player("Jogador1", conn1);
                p2 = new Player("Jogador2", conn2);
                
                System.out.println("Iniciando novo Jogo.");
                game = new Game(p1,p2);
                new Thread(game).start();
            }
        } catch (IOException ex) {
            Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void handshake(Socket sock) {
        //translate bytes of request to string
        String question, answer;
        String data = null;
        try {
            data = new Scanner(sock.getInputStream(),"UTF-8").useDelimiter("\\r\\n\\r\\n").next();
        } catch (IOException ex) {
            Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        question=new String(data);
        System.out.println(System.lineSeparator() +
                "------ Client asks ------"+System.lineSeparator()+
                question + System.lineSeparator() + 
                "------ End of question ------"+System.lineSeparator());

        Matcher get = Pattern.compile("^GET").matcher(data);

        if (get.find()) {
            Matcher match = Pattern.compile("Sec-WebSocket-Key: (.*)").matcher(data);
            match.find();
            byte[] response;
            try {
                answer = "HTTP/1.1 101 Switching Protocols"+ System.lineSeparator()
                        + "Connection: Upgrade"+ System.lineSeparator()
                        + "Upgrade: websocket"+ System.lineSeparator()
                        + "Sec-WebSocket-Accept: "
                        + DatatypeConverter.printBase64Binary(
                            MessageDigest.getInstance("SHA-1")
                                .digest((match.group(1) + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
                                    .getBytes("UTF-8")))
                        + System.lineSeparator() + System.lineSeparator();
                System.out.println(System.lineSeparator() +
                "------ Server answered ------"+System.lineSeparator()+
                answer + System.lineSeparator() + 
                "------ End of answer ------"+System.lineSeparator());
                response = answer.getBytes("UTF-8");
                sock.getOutputStream().write(response, 0, response.length);

            } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
                    Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(WarShipServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
